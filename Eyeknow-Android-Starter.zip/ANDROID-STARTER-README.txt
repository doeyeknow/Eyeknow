Eyeknow Android shell starter

Extract this archive and add android/ and .github/ to the root of your existing repository. Preserve the directory structure, including the hidden .github directory. Uploading the ZIP alone does not install the workflow.

Commit to the default branch. In GitHub Actions run Build Android debug APK. Download the eyeknow-debug-apk artifact after a successful run.

This source package has not been compiled or device-tested here. It is NOT an APK.

Scope: website loading and installation smoke test only. No native camera, capture bridge, file picker, automatic iris capture, or payment-specific integration is implemented. Do not use for purchase testing or production distribution.

The workflow provisions Gradle; no Gradle wrapper is included. Existing web files are not included or changed.
