package app.eyeknow.android

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var errorPanel: LinearLayout
    private val homeUrl = "https://eyeknow.app"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = android.widget.FrameLayout(this)
        webView = WebView(this)
        container.addView(webView, android.widget.FrameLayout.LayoutParams(-1, -1))
        errorPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            setPadding(48, 48, 48, 48)
            setBackgroundColor(Color.WHITE)
            visibility = View.GONE
        }
        errorPanel.addView(TextView(this).apply {
            text = "Could not load eyeknow. Check your connection and retry."
            textSize = 18f
            gravity = android.view.Gravity.CENTER
            setTextColor(Color.BLACK)
        })
        errorPanel.addView(Button(this).apply {
            text = "Retry"
            setOnClickListener {
                errorPanel.visibility = View.GONE
                webView.loadUrl(homeUrl)
            }
        })
        container.addView(errorPanel, android.widget.FrameLayout.LayoutParams(-1, -1))
        setContentView(container)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportMultipleWindows(false)
        }
        CookieManager.getInstance().setAcceptCookie(true)
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (isTrustedSite(request.url)) return false
                if (request.isForMainFrame) openExternalLink(request.url)
                return true
            }
            override fun onReceivedError(view: WebView, request: WebResourceRequest,
                error: android.webkit.WebResourceError) {
                if (request.isForMainFrame) errorPanel.visibility = View.VISIBLE
            }
            override fun onReceivedHttpError(view: WebView, request: WebResourceRequest,
                errorResponse: android.webkit.WebResourceResponse) {
                if (request.isForMainFrame && errorResponse.statusCode >= 400)
                    errorPanel.visibility = View.VISIBLE
            }
        }
        webView.loadUrl(homeUrl)
    }

    private fun isTrustedSite(uri: Uri): Boolean =
        uri.scheme == "https" && uri.host == "eyeknow.app" &&
            (uri.port == -1 || uri.port == 443)

    private fun openExternalLink(uri: Uri) {
        if (uri.scheme !in listOf("https", "http", "mailto", "tel")) return
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) {
            android.widget.Toast.makeText(this,
                "No app is available to open this link.",
                android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Legacy back navigation for this development build")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        webView.stopLoading()
        webView.destroy()
        super.onDestroy()
    }
}
